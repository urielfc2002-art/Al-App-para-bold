// src/App.tsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import ThreeDots from "./components/ThreeDots";
import Login from "./components/Login";
import Signup from "./components/Signup";
import MainMenu from "./components/MainMenu";
import Subscription from "./components/Subscription";




function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/tres-puntos" element={<ThreeDots />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/main" element={<MainMenu />} />
      <Route path="/subscription" element={<Subscription />} />
    </Routes>
  );
}

export default App;
