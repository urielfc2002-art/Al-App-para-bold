// src/components/Login.tsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth, db } from "../firebase";
import {
  signInWithEmailAndPassword,
  signInWithCredential,
  GoogleAuthProvider,
} from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import "../styles/Auth.css";

// 👇 Plugin nativo
import { FirebaseAuthentication } from "@capacitor-firebase/authentication";

const Login: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const goBySubscription = async (uid: string) => {
    try {
      const snap = await getDoc(doc(db, "users", uid));
      if (snap.exists() && snap.data().subscriptionStatus === "active") {
        navigate("/main");
      } else {
        navigate("/subscription");
      }
    } catch (e) {
      console.warn("[Login] Firestore check failed:", e);
      navigate("/subscription");
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      const { user } = await signInWithEmailAndPassword(auth, email, password);
      await goBySubscription(user.uid);
    } catch (err: any) {
      console.error("[Login] Email error:", err);
      setError(err?.message || "Error al iniciar sesión");
    }
  };

  const handleGoogleLogin = async () => {
    setError("");
    try {
      // Abre Google de forma nativa y devuelve credenciales (con skipNativeAuth: true)
      const res = await FirebaseAuthentication.signInWithGoogle();
      console.log("[Google Native] signInWithGoogle:", res);

      const idToken =
        (res as any)?.credential?.idToken ||
        (res as any)?.credential?.idToken; // doble chequeo intencional

      if (!idToken) {
        setError("No se recibió idToken de Google. Revisa SHA-1 y configuración.");
        console.error("[Google Native] idToken is null");
        return;
      }

      // Firmamos con el SDK Web de Firebase
      const credential = GoogleAuthProvider.credential(idToken);
      const { user } = await signInWithCredential(auth, credential);

      // Upsert de perfil en Firestore
      const userRef = doc(db, "users", user.uid);
      const exists = await getDoc(userRef);
      if (!exists.exists()) {
        await setDoc(userRef, {
          email: user.email,
          subscriptionStatus: "inactive",
          subscriptionType: null,
          startDate: null,
          expiryDate: null,
        });
      }

      await goBySubscription(user.uid);
    } catch (err: any) {
      console.error("[Login] Google error:", err);
      setError("Error al iniciar sesión con Google");
    }
  };

  return (
    <div className="login-container">
      <h1 className="login-title">AL</h1>
      <h2 className="login-subtitle">calculadora</h2>

      <div className="login-card">
        <p className="login-description">Vincula tu cuenta</p>
        {error && <p className="login-error">{error}</p>}

        <form onSubmit={handleEmailLogin}>
          <input
            type="email"
            placeholder="Correo electrónico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="login-input"
            required
          />
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="login-input"
            required
          />
          <button type="submit" className="btn-login">Ingresar</button>
        </form>

        <img
          src="/assets/icons/google-icon.png"
          alt="Iniciar con Google"
          className="btn-image"
          onClick={handleGoogleLogin}
        />

        <p className="login-footer">
          ¿No tienes cuenta?{" "}
          <span className="link" onClick={() => navigate("/signup")}>
            Crear cuenta
          </span>
        </p>
      </div>
    </div>
  );
};

export default Login;

