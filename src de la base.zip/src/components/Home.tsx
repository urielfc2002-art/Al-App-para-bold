// src/components/Home.tsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/Home.css";
import { App } from "@capacitor/app"; // 👈 trae { version, build } (build = versionCode en Android)

const Home: React.FC = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [appVersion, setAppVersion] = useState<string>("");
  const [appBuild, setAppBuild] = useState<string | number>("");
  const navigate = useNavigate();

  useEffect(() => {
    // Lee versión real desde nativo
    App.getInfo()
      .then((info) => {
        setAppVersion(info.version); // p.ej. "1.0.3"
        setAppBuild(info.build ?? ""); // en Android: versionCode (número)
      })
      .catch(() => {
        setAppVersion(""); // silencioso si falla
        setAppBuild("");
      });
  }, []);

  const handleCloseMenu = () => setMenuOpen(false);

  return (
    <div className="home-container" onClick={handleCloseMenu}>
      {/* Ícono AL decorativo */}
      <div className="al-icon">
        <img src="/assets/home.png" alt="AL" className="icon-al-img" />
      </div>

      {/* Botón menú (tres barras) */}
      <div
        className="menu-toggle"
        onClick={(e) => {
          e.stopPropagation();
          setMenuOpen(true);
        }}
      >
        <div className="bar" />
        <div className="bar" />
        <div className="bar" />
      </div>

      {/* Logo central */}
      <div className="logo-text">AL</div>
      <div className="subtitle">calculadora</div>

      {/* Botón Login */}
      <button
        className="btn-primary"
        onClick={() => navigate("/login")}
      >
        Iniciar
      </button>

      <p className="cta-text">
        ¿Aún no tienes una cuenta?{" "}
        <span className="link" onClick={() => navigate("/signup")}>
          Crear cuenta
        </span>
      </p>

      {/* Versión en la esquina inferior izquierda */}
      {(appVersion || appBuild) && (
        <p
          style={{
            position: "absolute",
            bottom: "10px",
            left: "12px",
            color: "#ffffff",
            opacity: 0.8,
            fontSize: "12px",
            margin: 0,
          }}
        >
          Versión {appVersion || "—"} (code: {appBuild || "—"})
        </p>
      )}

      {/* Menú lateral */}
      {menuOpen && (
        <div
          className="side-menu"
          onClick={(e) => e.stopPropagation()}
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            height: "100%",
            padding: "20px"
          }}
        >
          <div>
            <div className="visit-title">Visítanos en:</div>
            <a
              href="https://www.tiktok.com/@ftherreriayaluminio?is_from_webapp=1&sender_device=pc"
              target="_blank"
              rel="noreferrer"
              className="menu-item"
            >
              <img src="/assets/icons/tiktok.png" alt="TikTok" className="icon" />
              FT HERRERÍA Y ALUMINIO
            </a>
            <a
              href="https://www.youtube.com/@ftherreriayaluminio"
              target="_blank"
              rel="noreferrer"
              className="menu-item"
            >
              <img src="/assets/icons/youtube.png" alt="YouTube" className="icon" />
              FT HERRERÍA Y ALUMINIO
            </a>
            <a
              href="https://wa.me/522721917499"
              target="_blank"
              rel="noreferrer"
              className="menu-item"
            >
              <img src="/assets/icons/whatsapp.png" alt="WhatsApp" className="icon" />
              WhatsApp
            </a>
          </div>

          <div>
            <div className="visit-title" style={{ marginTop: "20px" }}>
              Soporte:
            </div>
            <a
              href="mailto:aloficialsoport@gmail.com?subject=Eliminación de cuenta&body=QUIERO ELIMINAR MI CUENTA: example@gmail.com"
              target="_blank"
              rel="noreferrer"
              className="menu-item"
            >
              <img src="/assets/icons/email.png" alt="Email" className="icon" />
              Eliminar cuenta
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;







