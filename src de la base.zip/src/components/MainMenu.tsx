// src/components/MainMenu.tsx
import React, { useState, useRef, useEffect } from "react";
import { Settings, DoorOpen as Door, ClipboardList, NotebookPen } from "lucide-react";
import { Capacitor } from "@capacitor/core";
import { WindowIcon } from "./WindowIcon";
import { WindowSubmenu } from "./WindowTypes";
import { QuoteSubmenu } from "./QuoteSubmenu";
import { DoorSubmenu } from "./DoorSubmenu";
import { Notes } from "./Notes";

type Screen = "main" | "windows" | "doors" | "quote" | "notes";

function MenuButton({
  icon: Icon,
  title,
  subtitle,
  isCustomIcon = false,
  onClick,
}: {
  icon: React.ElementType;
  title: string;
  subtitle: string;
  isCustomIcon?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      className="flex items-center mb-8 group transition-transform hover:scale-105"
      onClick={onClick}
      aria-label={`Ir a ${title.toLowerCase()}`}
    >
      <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-lg mr-6">
        {isCustomIcon ? (
          <Icon size={48} className="text-[#003366]" />
        ) : (
          <Icon size={40} className="text-[#003366]" />
        )}
      </div>
      <div className="text-left">
        <h2 className="text-white text-3xl font-bold">{title}</h2>
        <p className="text-gray-300 text-lg">{subtitle}</p>
      </div>
    </button>
  );
}

const MainMenu: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>("main");
  const activeBackHandlerRef = useRef<(() => boolean) | null>(null);
  const listenerHandleRef = useRef<any>(null);

  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      (async () => {
        try {
          const { App } = await import("@capacitor/app");

          const handleBackButton = () => {
            if (activeBackHandlerRef.current) {
              const shouldPreventDefault = activeBackHandlerRef.current();
              return { shouldPreventDefault };
            }
            if (currentScreen !== "main") {
              setCurrentScreen("main");
              return { shouldPreventDefault: true };
            }
            return { shouldPreventDefault: false };
          };

          App.addListener("backButton", handleBackButton).then((listenerHandle) => {
            listenerHandleRef.current = listenerHandle;
          });
        } catch (err) {
          console.error("Capacitor App plugin not available:", err);
        }
      })();
    }

    return () => {
      if (
        listenerHandleRef.current &&
        typeof listenerHandleRef.current.remove === "function"
      ) {
        listenerHandleRef.current.remove();
      }
    };
  }, [currentScreen]);

  const registerBackHandler = (handler: () => boolean) => {
    activeBackHandlerRef.current = handler;
    return () => {
      if (activeBackHandlerRef.current === handler) {
        activeBackHandlerRef.current = null;
      }
    };
  };

  if (currentScreen === "windows") {
    return (
      <WindowSubmenu
        onClose={() => setCurrentScreen("main")}
        onSelectWindow={() => {}}
        onRegisterBackHandler={registerBackHandler}
      />
    );
  }

  if (currentScreen === "doors") {
    return (
      <DoorSubmenu
        onBack={() => setCurrentScreen("main")}
        onRegisterBackHandler={registerBackHandler}
      />
    );
  }

  if (currentScreen === "quote") {
    return (
      <QuoteSubmenu
        onBack={() => setCurrentScreen("main")}
        onRegisterBackHandler={registerBackHandler}
      />
    );
  }

  if (currentScreen === "notes") {
    return (
      <Notes
        onBack={() => setCurrentScreen("main")}
        onRegisterBackHandler={registerBackHandler}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#003366] flex flex-col items-center px-4">
      <div className="w-full pt-6 px-6">
        <Settings className="text-white w-12 h-12" />
      </div>

      <div className="text-center my-16">
        <h1 className="text-white text-5xl font-bold mb-2 whitespace-nowrap">¿QUE VAMOS A</h1>
        <h1 className="text-white text-5xl font-bold">TRABAJAR?</h1>
      </div>

      <div className="w-full max-w-2xl px-4">
        <MenuButton
          icon={WindowIcon}
          title="VENTANAS"
          subtitle="LÍNEA NACIONAL DE 3"
          isCustomIcon={true}
          onClick={() => setCurrentScreen("windows")}
        />
        <MenuButton
          icon={Door}
          title="PUERTAS"
          subtitle="LÍNEA NACIONAL DE 3"
          onClick={() => setCurrentScreen("doors")}
        />
        <MenuButton
          icon={ClipboardList}
          title="COTIZACION"
          subtitle="LÍNEA NACIONAL DE 3"
          onClick={() => setCurrentScreen("quote")}
        />
        <MenuButton
          icon={NotebookPen}
          title="NOTAS"
          subtitle=""
          onClick={() => setCurrentScreen("notes")}
        />
      </div>
    </div>
  );
};

export default MainMenu;
