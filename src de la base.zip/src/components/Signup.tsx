// src/components/Signup.tsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth, db } from "../firebase";
import {
  createUserWithEmailAndPassword,
  signInWithCredential,
  GoogleAuthProvider,
} from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import "../styles/Auth.css";

// 👇 Plugin nativo
import { FirebaseAuthentication } from "@capacitor-firebase/authentication";

const Signup: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Verifica la contraseña");
      return;
    }

    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, password);

      await setDoc(doc(db, "users", user.uid), {
        email,
        subscriptionStatus: "inactive",
        subscriptionType: null,
        startDate: null,
        expiryDate: null,
      });

      navigate("/subscription");
    } catch (err: any) {
      console.error("[Signup] Email error:", err);
      setError("Error al registrarse: " + (err?.message || err));
    }
  };

  const handleGoogleSignup = async () => {
    setError("");
    try {
      const res = await FirebaseAuthentication.signInWithGoogle();
      console.log("[Google Native] signInWithGoogle:", res);

      const idToken =
        (res as any)?.credential?.idToken ||
        (res as any)?.credential?.idToken;

      if (!idToken) {
        setError("No se recibió idToken de Google. Revisa SHA-1 y configuración.");
        console.error("[Google Native] idToken is null");
        return;
      }

      // Firmamos con el SDK Web de Firebase
      const credential = GoogleAuthProvider.credential(idToken);
      const { user } = await signInWithCredential(auth, credential);

      await setDoc(doc(db, "users", user.uid), {
        email: user.email,
        subscriptionStatus: "inactive",
        subscriptionType: null,
        startDate: null,
        expiryDate: null,
      });

      navigate("/subscription");
    } catch (err: any) {
      console.error("[Signup] Google error:", err);
      setError("Error con el registro con Google");
    }
  };

  return (
    <div className="login-container">
      <h1 className="login-title">AL</h1>
      <h2 className="login-subtitle">calculadora</h2>

      <div className="login-card">
        <p className="login-description">Crea tu cuenta para empezar a trabajar</p>
        {error && <p className="login-error">{error}</p>}

        <form onSubmit={handleEmailSignup}>
          <input
            type="email"
            placeholder="Correo electrónico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="login-input"
            required
          />
          <input
            type="password"
            placeholder="Contraseña (mínimo 6 caracteres)"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="login-input"
            required
          />
          <input
            type="password"
            placeholder="Verificar contraseña"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="login-input"
            required
          />
          <button type="submit" className="btn-login">Crear cuenta</button>
        </form>

        <img
          src="/assets/icons/google-icon.png"
          alt="Registrarse con Google"
          className="btn-image"
          onClick={handleGoogleSignup}
        />

        <p className="login-footer">
          ¿Ya tienes cuenta?{" "}
          <span className="link" onClick={() => navigate("/login")}>
            Iniciar sesión
          </span>
        </p>
      </div>
    </div>
  );
};

export default Signup;

