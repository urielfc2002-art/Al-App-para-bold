// src/components/Subscription.tsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Capacitor } from "@capacitor/core";
import { getAuth } from "firebase/auth";
import { getFirestore, doc, setDoc } from "firebase/firestore";
import "../styles/Subscription.css";

import "cordova-plugin-purchase";
const IAP: any = (window as any).CdvPurchase || {};
const { store, ProductType, Platform } = IAP;

const PRODUCT_ID = "premium.mensual";
const BASEPLAN_MONTH = "sub-mes";   // mensual
const BASEPLAN_YEAR  = "sub-anual"; // anual

function safe(o: any) { try { return JSON.parse(JSON.stringify(o)); } catch { return o; } }

export default function Subscription() {
  const [loading, setLoading] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [productObj, setProductObj] = useState<any>(null);

  const nav = useNavigate();
  const auth = getAuth();
  const db = getFirestore();

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) { console.warn("[IAP] no-nativo"); return; }
    if (!store) { console.error("[IAP] store no disponible"); return; }
    try { store.verbosity = store.DEBUG; } catch {}

    const offErr = store.error((e: any) => {
      console.error("[IAP][store.error]", safe(e));
      alert(`Billing error (${e?.code ?? "UNK"}): ${e?.message ?? "desconocido"}`);
    });

    const offApproved = store.when().approved(async (tx: any) => {
      try { await tx.verify(); } catch (e) { console.error("[IAP] verify err", e); }
    });

    const offVerified = store.when().verified(async (rcpt: any) => {
      try {
        const u = auth.currentUser;
        if (u) {
          await setDoc(
            doc(db, "users", u.uid),
            { subscriptionStatus: "active", updatedAt: new Date().toISOString() },
            { merge: true }
          );
        }
      } catch (e) {
        console.error("[IAP] Firestore err", e);
      }
      try { await rcpt.finish(); } catch {}
      alert("¡Compra exitosa!");
      nav("/main");
    });

    (async () => {
      store.register([{ id: PRODUCT_ID, type: ProductType.PAID_SUBSCRIPTION, platform: Platform.GOOGLE_PLAY }]);
      await store.initialize([Platform.GOOGLE_PLAY]);
      await store.update();

      const p = store.get(PRODUCT_ID, Platform.GOOGLE_PLAY);
      setProductObj(p || null);
      console.log("[IAP] product:", safe(p));
      console.log("[IAP] product.offers:", safe(p?.offers));

      setReady(true);
    })().catch(e => console.error("[IAP] init err", e));

    return () => {
      offErr?.remove?.();
      offApproved?.remove?.();
      offVerified?.remove?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- Selección de la oferta correcta ----
  // Primero por basePlanId; si no existe, por periodo (P1M / P1Y) en las pricing phases.
  const pickOffer = (basePlanId: string, wantedPeriod: "P1M" | "P1Y") => {
    const offers: any[] = productObj?.offers || [];
    if (!offers.length) return null;

    // 1) Por base plan id (variantes que expone CdvPurchase)
    let off: any =
      offers.find(o => o?.googleplay?.base_plan_id === basePlanId) ||
      offers.find(o => o?.googlePlay?.basePlanId === basePlanId) ||
      offers.find(o => o?.basePlanId === basePlanId);
    if (off) return off;

    // 2) Por periodo (en pricing phases)
    const hasPeriod = (o: any, period: string) => {
      const phases = o?.pricingPhases || o?.pricing?.phases || [];
      return phases?.some((ph: any) =>
        ph?.billingPeriod === period || ph?.billing_period === period || ph?.period === period
      );
    };
    off = offers.find(o => hasPeriod(o, wantedPeriod));
    if (off) return off;

    // 3) No devolvemos otra cosa: si no hay match, devolvemos null para no comprar el plan equivocado.
    return null;
  };

  const ensureProduct = async () => {
    if (productObj) return true;
    try {
      await store.update();
      const p = store.get(PRODUCT_ID, Platform.GOOGLE_PLAY);
      setProductObj(p || null);
      return !!p;
    } catch {
      return false;
    }
  };

  const orderStrict = async (basePlanId: string) => {
    const ok = await ensureProduct();
    if (!ok) { alert("Tienda no lista. Instala desde Play y usa una cuenta tester."); return; }

    const wantedPeriod = basePlanId === BASEPLAN_YEAR ? "P1Y" : "P1M";
    const offer = pickOffer(basePlanId, wantedPeriod);
    console.log("[IAP] selected offer for", basePlanId, "->", safe(offer));

    if (!offer) {
      alert(
        `No se encontró la oferta del plan "${basePlanId}" (${wantedPeriod}). ` +
        `Revisa en Play Console que ese base plan esté ACTIVO en el producto "${PRODUCT_ID}".`
      );
      return; // ⬅️ importante: no caemos a order(productObj) para no comprar el otro plan
    }

    try {
      const res = await store.order(offer);
      console.log("[IAP] order(offer) ->", safe(res));
      if (res?.isError) throw res;
    } catch (e: any) {
      console.error("[IAP] order error", safe(e));
      alert(`Fallo en la compra (${e?.code ?? "UNK"}): ${e?.message ?? "Error"}`);
    }
  };

  const buyMonthly = async () => {
    setLoading(BASEPLAN_MONTH);
    try { await orderStrict(BASEPLAN_MONTH); } finally { setLoading(null); }
  };
  const buyYearly = async () => {
    setLoading(BASEPLAN_YEAR);
    try { await orderStrict(BASEPLAN_YEAR); } finally { setLoading(null); }
  };

  const restore = async () => {
    try { await store.restorePurchases(); alert("Restauración solicitada."); }
    catch (e) { console.error("[IAP] restore err", e); alert("No fue posible restaurar compras."); }
  };

  return (
    <div className="subscription-container">
      <div className="al-icon"><img src="/assets/home.png" alt="AL" /></div>
      <h1 className="subscription-title">AL Calculadora</h1>

      <div className="subscription-card">
        <h2>Actualizar cuenta</h2>

        <div className="subscription-box">
          <ul className="subscription-features">
            <li><img src="/assets/Check.png" alt="✔" /> Editor de formulas.</li>
            <li><img src="/assets/Check.png" alt="✔" /> Cotizador de proyectos.</li>
            <li><img src="/assets/Check.png" alt="✔" /> Blok de notas inteligente.</li>
          </ul>

          <div className="sub-option">
            <p><strong>$199 MXN</strong> <span className="sub-text">/mes</span></p>
            <button className="subscribe-button" onClick={buyMonthly} disabled={!!loading || !ready}>
              {loading === BASEPLAN_MONTH ? "Procesando..." : "Actualizar ahora."}
            </button>
          </div>

          <div className="sub-option">
            <p>
              <strong>$2,000 MXN</strong> <span className="sub-text">/año</span>
              <span className="discount-badge">-20%</span>
            </p>
            <button className="subscribe-button" onClick={buyYearly} disabled={!!loading || !ready}>
              {loading === BASEPLAN_YEAR ? "Procesando..." : "Actualizar ahora."}
            </button>
          </div>

          <button className="restore-button" onClick={restore} disabled={!ready}>Restaurar compras</button>
        </div>
      </div>
    </div>
  );
}

