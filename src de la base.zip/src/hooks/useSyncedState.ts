import { useState, useEffect, useCallback } from 'react';

// Canal dedicado para sincronización entre pestañas
const channel = new BroadcastChannel('window_calculator_sync');

export function useSyncedState<T>(key: string, defaultValue: T) {
  // Inicializar estado con valor del localStorage o valor por defecto
  const [value, setValue] = useState<T>(() => {
    try {
      const saved = localStorage.getItem(key);
      if (saved !== null) {
        const parsed = JSON.parse(saved);
        return parsed ?? defaultValue;
      }
    } catch (error) {
      console.error(`Error loading state for key "${key}":`, error);
    }
    return defaultValue;
  });

  // Manejar cambios en localStorage
  const handleStorageChange = useCallback((event: StorageEvent) => {
    if (event.key === key && event.newValue !== null) {
      try {
        const newValue = JSON.parse(event.newValue);
        setValue(newValue ?? defaultValue);
      } catch (error) {
        console.error(`Error parsing storage value for key "${key}":`, error);
        setValue(defaultValue);
      }
    }
  }, [key, defaultValue]);

  // Manejar mensajes del canal de broadcast
  const handleMessage = useCallback((event: MessageEvent) => {
    if (event.data?.key === key) {
      try {
        setValue(event.data.value ?? defaultValue);
      } catch (error) {
        console.error(`Error handling broadcast message for key "${key}":`, error);
        setValue(defaultValue);
      }
    }
  }, [key, defaultValue]);

  // Configurar listeners
  useEffect(() => {
    window.addEventListener('storage', handleStorageChange);
    channel.addEventListener('message', handleMessage);

    // Solicitar estado actual al abrir nueva pestaña
    channel.postMessage({ type: 'REQUEST_STATE', key });

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      channel.removeEventListener('message', handleMessage);
    };
  }, [key, handleStorageChange, handleMessage]);

  // Función para actualizar el estado
  const setSyncedValue = useCallback((newValue: T | ((prev: T) => T)) => {
    try {
      const actualNewValue = newValue instanceof Function ? newValue(value) : newValue;
      
      // Actualizar estado local
      setValue(actualNewValue);
      
      // Persistir en localStorage
      localStorage.setItem(key, JSON.stringify(actualNewValue));
      
      // Notificar a otras pestañas
      channel.postMessage({ key, value: actualNewValue });
    } catch (error) {
      console.error(`Error saving state for key "${key}":`, error);
    }
  }, [key, value]);

  return [value, setSyncedValue] as const;
}