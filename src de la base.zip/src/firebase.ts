// src/firebase.ts
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCLx-cNIPPZy_Nq6fu08jtzwhG-wg8S8ns",
  authDomain: "alcalculadorav2.firebaseapp.com",
  projectId: "alcalculadorav2",
  storageBucket: "alcalculadorav2.firebasestorage.app",
  messagingSenderId: "338636322262",
  appId: "1:338636322262:android:ba3c5b0ed00213fdb3a077"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);
